from coffee import howToWinACoffee

# Appel de la fonction
howToWinACoffee.howToWinACoffee()
