def count_in_list(lst, item):
    return lst.count(item)
